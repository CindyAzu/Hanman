return {
        id = 'StarAlistar',
        name = 'Star Guardian Alistar',
        load = function()
          return player.charName == "Alistar"
        end,
      }
