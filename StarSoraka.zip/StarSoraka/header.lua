return {
        id = 'StarSoraka',
        name = 'Star Guardian Soraka',
        load = function()
          return player.charName == "Soraka"
        end,
      }